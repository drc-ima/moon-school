define("ace/snippets/groovy",["require","exports","module"],function(e,t,n){"use strict";t.snippetText=undefined,t.scope="groovy"});                (function() {
                    window.require(["ace/snippets/groovy"], function(m) {
                        if (typeof module == "object" && typeof exports == "object" && module) {
                            module.exports = m;
                        }
                    });
                })();
            